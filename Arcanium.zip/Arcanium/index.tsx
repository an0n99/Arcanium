'use client'

import { useState } from 'react'
import { PropertiesPage } from '@/components/PropertiesPage'
import { ListPropertyPage } from '@/components/ListPropertyPage'

export default function Home() {
  const [currentPage, setCurrentPage] = useState('properties')

  return (
    <main>
      {currentPage === 'properties' && <PropertiesPage onListProperty={() => setCurrentPage('listProperty')} />}
      {currentPage === 'listProperty' && <ListPropertyPage onBack={() => setCurrentPage('properties')} />}
    </main>
  )
}