import { useState } from 'react'
import { Moon, Sun, MoreHorizontal, Calendar, Home, DollarSign } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock data for properties
const properties = [
  {
    id: 'PROP001',
    address: '123 Main St, Anytown, USA',
    price: '$250,000',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 1500,
    description: 'A beautiful family home in a quiet neighborhood.',
    image: '/placeholder.svg?height=400&width=600'
  },
  {
    id: 'PROP002',
    address: '456 Elm St, Somewhere, USA',
    price: '$350,000',
    bedrooms: 4,
    bathrooms: 3,
    sqft: 2000,
    description: 'Spacious house with a large backyard and modern amenities.',
    image: '/placeholder.svg?height=400&width=600'
  },
]

export default function PropertiesPage({ onListProperty, onViewMortgages }: { onListProperty: () => void, onViewMortgages: () => void }) {
  const [darkMode, setDarkMode] = useState(false)

  const handleSubmit = (formType: string, data: any) => {
    console.log(`${formType} form submitted:`, data)
  }

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 dark:from-purple-900 dark:via-pink-900 dark:to-red-900 min-h-screen p-8">
        <div className="max-w-6xl mx-auto">
          <header className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-white">Arcanium Real Estate</h1>
            <div className="flex items-center space-x-4">
              <Button variant="secondary" onClick={onListProperty}>
                <Home className="mr-2 h-4 w-4" />
                List a Property
              </Button>
              <Button variant="secondary" onClick={onViewMortgages}>
                <DollarSign className="mr-2 h-4 w-4" />
                View Mortgages
              </Button>
              <div className="flex items-center space-x-2">
                <Sun className="h-5 w-5 text-white" />
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
                <Moon className="h-5 w-5 text-white" />
              </div>
            </div>
          </header>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property) => (
              <Card key={property.id} className="bg-white dark:bg-gray-800 overflow-hidden">
                <img src={property.image} alt={property.address} className="w-full h-48 object-cover" />
                <CardContent className="p-4">
                  <h2 className="text-xl font-semibold mb-2 dark:text-white">{property.address}</h2>
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 mb-2">{property.price}</p>
                  <div className="flex justify-between text-sm text-gray-600 dark:text-gray-300 mb-2">
                    <span>{property.bedrooms} beds</span>
                    <span>{property.bathrooms} baths</span>
                    <span>{property.sqft} sqft</span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">ID: {property.id}</p>
                </CardContent>
                <CardFooter className="bg-gray-50 dark:bg-gray-700 p-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full">
                        <MoreHorizontal className="mr-2 h-4 w-4" /> More Info
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>{property.address}</DialogTitle>
                        <DialogDescription>{property.description}</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button>Buy Now</Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Buy Now</DialogTitle>
                              <DialogDescription>Please fill out the form to proceed with your purchase.</DialogDescription>
                            </DialogHeader>
                            <form onSubmit={(e) => {
                              e.preventDefault()
                              const formData = new FormData(e.currentTarget)
                              handleSubmit('Buy Now', Object.fromEntries(formData))
                            }} className="space-y-4">
                              <div>
                                <Label htmlFor="buyName">Name</Label>
                                <Input id="buyName" name="name" required />
                              </div>
                              <div>
                                <Label htmlFor="buyEmail">Email</Label>
                                <Input id="buyEmail" name="email" type="email" required />
                              </div>
                              <Button type="submit">Submit</Button>
                            </form>
                          </DialogContent>
                        </Dialog>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline">Make an Offer</Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Make an Offer</DialogTitle>
                              <DialogDescription>Please fill out the form to make an offer.</DialogDescription>
                            </DialogHeader>
                            <form onSubmit={(e) => {
                              e.preventDefault()
                              const formData = new FormData(e.currentTarget)
                              handleSubmit('Make an Offer', Object.fromEntries(formData))
                            }} className="space-y-4">
                              <div>
                                <Label htmlFor="offerName">Name</Label>
                                <Input id="offerName" name="name" required />
                              </div>
                              <div>
                                <Label htmlFor="offerEmail">Email</Label>
                                <Input id="offerEmail" name="email" type="email" required />
                              </div>
                              <div>
                                <Label htmlFor="offerAmount">Offer Amount</Label>
                                <Input id="offerAmount" name="amount" type="number" required />
                              </div>
                              <Button type="submit">Submit Offer</Button>
                            </form>
                          </DialogContent>
                        </Dialog>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="secondary">Book a Viewing</Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Book a Viewing</DialogTitle>
                              <DialogDescription>Please fill out the form to book a viewing.</DialogDescription>
                            </DialogHeader>
                            <form onSubmit={(e) => {
                              e.preventDefault()
                              const formData = new FormData(e.currentTarget)
                              handleSubmit('Book a Viewing', Object.fromEntries(formData))
                            }} className="space-y-4">
                              <div>
                                <Label htmlFor="viewingName">Name</Label>
                                <Input id="viewingName" name="name" required />
                              </div>
                              <div>
                                <Label htmlFor="viewingEmail">Email</Label>
                                <Input id="viewingEmail" name="email" type="email" required />
                              </div>
                              <div>
                                <Label htmlFor="viewingDate">Preferred Date</Label>
                                <Input id="viewingDate" name="date" type="date" required />
                              </div>
                              <div>
                                <Label htmlFor="viewingTime">Preferred Time</Label>
                                <Input id="viewingTime" name="time" type="time" required />
                              </div>
                              <div>
                                <Label htmlFor="viewingMessage">Message (Optional)</Label>
                                <Textarea id="viewingMessage" name="message" />
                              </div>
                              <Button type="submit">Book Viewing</Button>
                            </form>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}