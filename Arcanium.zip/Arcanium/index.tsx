'use client'

import { useState } from 'react'
import PropertiesPage from '@/components/PropertiesPage'
import ListPropertyPage from '@/components/ListPropertyPage'
import MortgageOffersPage from '@/components/MortgageOffersPage'

export default function Home() {
  const [currentPage, setCurrentPage] = useState('properties')

  return (
    <main>
      {currentPage === 'properties' && (
        <PropertiesPage 
          onListProperty={() => setCurrentPage('listProperty')}
          onViewMortgages={() => setCurrentPage('mortgages')}
        />
      )}
      {currentPage === 'listProperty' && <ListPropertyPage onBack={() => setCurrentPage('properties')} />}
      {currentPage === 'mortgages' && <MortgageOffersPage onBack={() => setCurrentPage('properties')} />}
    </main>
  )
}